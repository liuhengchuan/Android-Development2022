//app.js
App({
    onLaunch: function () {
      wx.cloud.init({
        env: 'cloud1-0g6p9rrd6e6c3359',
        traceUser: true,
      })
      wx.setStorageSync('loginif', false)
    },

    getUserInfo: function (cb) {
        /*    var that = this
            if (this.globalData.userInfo) {
              typeof cb == "function" && cb(this.globalData.userInfo)
            } else {
              //调用登录接口
              wx.getUserInfo({
                withCredentials: false,
                success: function(res) {
                  that.globalData.userInfo = res.userInfo
                  typeof cb == "function" && cb(that.globalData.userInfo)
                }
              })
            }*/
    },

    globalData: {
        // api: "https://hs.api.boolv.com",//接口服务地址
        // imgUrl: "http://f.boolv.com",//图片服务地址
        // mobApi: "https://s.boolv.com",//手机服务地址
        // gaoDeKey: '972cafdc2472d8f779c5274db770ac22',//高德web API服务key
        // version: '0.1.0',//当前版本号

        personInfo: {
          phoneNumber: "",
          nickName: "",
          password: "",
          sex: 0,
          addr: ""
        },
        loginif: false,
    }

  
})
