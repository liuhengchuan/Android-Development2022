// pages/detail/detail.js
const db = wx.cloud.database();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    detail: "",
    category: "",
    judge: "",
    orderListArr: ""
  },


  /**
   * 图片预览
   */
  previewImage: function (e) {
    var current = e.target.dataset.src;

    wx.previewImage({
      current: current, // 当前显示图片的http链接  
      urls: this.data.detail.imgSrc // 需要预览的图片http链接列表  
    })
  },


  /**
   * 收藏
   */
  addFavorite(){
    var that = this;
    // 
    db.collection('product').doc(that.data.detail._id).update({
      // data 传入需要局部更新的数据
      data: {
        // 表示将 done 字段置为 true
        isFav: true
      },
      success: function(res) {
        console.log(res),
        wx.showToast({
          title: '收藏成功',
          icon: 'none',
          // duration: 2000,
        })
        that.setData({
          judgeClick: true
        })
        // setTimeout(function(){
        //   wx.switchTab({
        //     url: '/pages/index/index'
        //   })
        // },2000)
      }
    })
    // this.onLoad()
  },


  removeFavorite(){
    var that = this;
    db.collection('product').doc(that.data.detail._id).update({
      // data 传入需要局部更新的数据
      data: {
        // 表示将 done 字段置为 true
        isFav: false
      },
      success: function(res) {
        console.log(res.data)
        wx.showToast({
          title: '取消收藏成功',
          icon: 'none',
          // duration: 2000,
        })
        that.setData({
          judgeClick: false
        })
      }
    })
    this.onLoad()
  },


  contact(){

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    var that = this;
    console.log(options);
    var orderListArr = wx.getStorageSync('allOrder');
    // var orderListArr
    // db.collection('product').get({
    //   success: function(res) {
    //     // res.data 是一个包含集合中有权限访问的所有记录的数据，不超过 20 条
    //     console.log(res.data)
    //     that.setData({
    //       "orderListArr": res.data,
    //     })
    //     // wx.setStorageSync('allOrder', res.data)
    //   }
    // })
    // console.log(orderListArr)
    // var order
    if(options.judge === "false"){
      for (var list in orderListArr){
        // console.log(list)
        if(orderListArr[list]._id === options.productId){
          this.setData({
            detail: orderListArr[list],
            // judge: false,
            judgeClick: orderListArr[list].isFav
            // judgeClick: false
          })
        }
      }
    }else{
      db.collection("product").where({
        _id: options.productId
      })
      .get({
        success: function(res) {
          console.log(res.data)
          that.setData({
            detail: res.data[0],
            judgeClick: true,
          })
        }
      })
      // this.setData({
      //   judgeClick: true
      // })
    }
   
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})