// pages/order/order.js
//获取应用实例
var app = getApp();
var util = require('../../utils/util.js');
const db = wx.cloud.database();
Page({

    /**
     * 页面的初始数据
     */
    data: {
        tabs: ['未完成订单', '所有订单'],
        stv: {
            windowWidth: 0,
            lineWidth: 0,
            offset: 0,
            tStart: false
        },
        activeTab: 0,
        page: 1,
        hasData: true,
        isNotData: true,
        orderListArr: [],
        myOrderList: [],
        // myPhonenumber
    },

    getOrderList(){
      var myPhonenumber = wx.getStorageSync('userInfo').phonenumber;
      // console.log(myPhonenumber)
      var that = this;
      db.collection('product').get({
        success: function(res) {
          // res.data 是一个包含集合中有权限访问的所有记录的数据，不超过 20 条
          console.log(res.data)
          that.setData({
            "orderListArr": res.data,
          })
          wx.setStorageSync('allOrder', res.data)
        }
      })
      // wx.setStorageSync('allOrder', this.data.orderListArr)
      db.collection('product').where({
        phonenumber: myPhonenumber,
      })
      .get({
        success: function(res) {
          // res.data 是一个包含集合中有权限访问的所有记录的数据，不超过 20 条
          console.log(res.data)
          that.setData({
            "myOrderList": res.data,
          })
          wx.setStorageSync('myOrder', res.data)
        }
      })
      // this.setData({
      //   'myOrderList': wx.getStorageSync('myOrder')
      // })
    },

    _updateSelectedPage(page) {
      let {tabs, stv, activeTab} = this.data;
      activeTab = page;
      this.setData({activeTab: activeTab})
      stv.offset = stv.windowWidth * activeTab;
      this.setData({stv: this.data.stv})
    },

    handlerTabTap(e) {
        this._updateSelectedPage(e.currentTarget.dataset.index);
    },
    
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function () {
      // util.isLoginModal();
      try {
          let {tabs} = this.data;
          var res = wx.getSystemInfoSync()
          this.windowWidth = res.windowWidth;
          this.data.stv.lineWidth = this.windowWidth / this.data.tabs.length;
          this.data.stv.windowWidth = res.windowWidth;
          this.setData({stv: this.data.stv})
          this.tabsCount = tabs.length;
      } catch (e) {
          console.log(e);
      }
      //获取消息列表
      try {
        var value = wx.getStorageSync('loginif')
        if (value) {
          this.getOrderList();
        }
        else{
          wx.showToast({
            title: '您还未登录',
            duration: 1000,
          })
          setTimeout(function(){
            wx.navigateTo({
              url: '../account/login',
            }) 
          },2000)
        }
      } catch (e) {
        // Do something when catch error
      }
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
      // this.getOrderList()
      this.onLoad()
      // const pages = getCurrentPages()
      // const perpage = pages[pages.length - 1]
      // perpage.onLoad()  
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {
        if (!this.data.hasData) {
            return;
        }
        //获取消息列表
        this.getOrderList();
    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    },
    
})