// pages/account/login.js
//获取应用实例
var app = getApp();
var util = require('../../utils/util.js');
const db = wx.cloud.database({env: "cloud1-0g6p9rrd6e6c3359"});
import WxValidate from '../../utils/validate';

var inputContent = {};//输入内容
Page({

    /**
     * 页面的初始数据
     */
    data: {
      userInfo: {
        phonenumber: "",
        nickname: "",
        password: "",
      },
      currentTab: 0,   // tab切换
      verifyPsd: false,
      verifyExist: false,
      phoneLegal: false,
      psdOneLegal: false,
      psdLegal: false,
      nameLegal: false,
      test: ""
        // paracont: "获取验证码",//验证码文字
        // vcdisabled: true,//验证码按钮状态
        // verifycode: ""//返回的验证码
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        // 页面初始化 options为页面跳转所带来的参数

        // //删除记住用户信息
        // wx.removeStorageSync("userid");
        // wx.removeStorageSync("usersecret");
        // wx.removeStorageSync("user");
        // wx.removeStorageSync("token");
        // wx.removeStorageSync("expires_in");
        // //接口API授权 type 1.是公共授权  2.登录授权
        // util.authorization(1, function () {
        //     //微信授权登录
        //     util.wxLogin();
        // })

    },

    /**
     * 点击tab切换
     */
    swichNav: function (e) {
        util.swichNav(e, this)
    },

    bindPhonenumber: function(e){
      if(e.detail.value.length==0){
        this.setData({
          "phoneLegal": false,
        })
      }else{
        this.setData({
          "userInfo.phonenumber": e.detail.value,
          "phoneLegal": true,
        })
      }
    },

    bindPasswordOne: function(e){
      if(e.detail.value.length==0||e==null){
        this.setData({
          "psdOneLegal": false,
        })
      }else{
        this.setData({
          "userInfo.password": e.detail.value,
          "psdOneLegal": true,
        })
        var that = this;
        db.collection('user').where({
          phonenumber: this.data.userInfo.phonenumber.toString()
        })
        .get({
          success: function(res) {
            console.log(res.data)
            if(that.data.userInfo.password === res.data[0].password){
              that.setData({
                "userInfo.nickname": res.data[0].nickname,
                "verifyPsd": true,
              })
            }else{
              that.setData({
                "verifyPsd": false,
              })
            }
          }
        })
      }
    },

    bindNickname: function(e){
      if(e.detail.value.length==0){
        this.setData({
          "nameLegal": false,
        })
      }else{
        this.setData({
          "userInfo.nickname": e.detail.value,
          "nameLegal": true,
        })
      }
    },

    bindPassword: function(e){
      if(e.detail.value.length==0){
        this.setData({
          "psdLegal": false,
        })
      }else{
        this.setData({
          "userInfo.password": e.detail.value,
          "psdLegal": true,
        })
        var that = this;
        db.collection('user').where({
          phonenumber: this.data.userInfo.phonenumber.toString()
        })
        .get({
          success: function(res) {
            console.log(res.data)
            if(that.data.userInfo.password === res.data[0].password){
              that.setData({
                "userInfo.nickname": res.data[0].nickname,
                "verifyPsd": true,
              })
            }else{
              that.setData({
                "verifyPsd": false,
              })
            }
          }
        })
      }
    },

    loginSubmit(){
      if(this.data.currentTab == 0){
        if(!this.data.phoneLegal||!this.data.psdOneLegal){
          wx.showToast({
            title: '输入不能为空',
          })
        }
        else{
          var that = this;
          if(that.data.verifyPsd){
            // app.globalData.personInfo.password = that.data.userInfo.password;
            // app.globalData.personInfo.phoneNumber = that.data.userInfo.phoneNumber;
            // app.globalData.personInfo.nickName = that.data.userInfo.nickName;
            // // app.globalData.personInfo = that.data.userInfo;
            // app.globalData.personInfo.loginif = true;
            try {
              wx.setStorageSync('userInfo', that.data.userInfo)
              wx.setStorageSync('loginif', true)
            } catch (e) { }
            wx.showToast({
              title: '登录成功',
              icon: 'none',
              duration: 2000,
            })
            setTimeout(function(){
              wx.switchTab({
                url: '/pages/account/account'
              })  
            },2000)
          }else{
            wx.showToast({
              title: '密码错误',
            })
          }
        }
      }
      else{
        if(!this.data.nameLegal||!this.data.psdLegal){
          wx.showToast({
            title: '输入不能为空',
          })
        }else{
          var that = this;
          if(that.data.verifyPsd){
            // app.globalData.personInfo.password = that.data.userInfo.password;
            // app.globalData.personInfo.phoneNumber = that.data.userInfo.phoneNumber;
            // app.globalData.personInfo.nickName = that.data.userInfo.nickName;
            // // app.globalData.personInfo = that.data.userInfo;
            // app.globalData.personInfo.loginif = true;
            try {
              wx.setStorageSync('userInfo', that.data.userInfo)
              wx.setStorageSync('loginif', true)
            } catch (e) { }
            wx.showToast({
              title: '登录成功',
              icon: 'none',
              duration: 2000,
            })
            setTimeout(function(){
              wx.switchTab({
                url: '/pages/account/account'
              })  
            },2000)
          }else{
            wx.showToast({
              title: '密码错误',
            })
          }
        }
      }
    },

    // /**
    //  * 登录
    //  */
    // loginapp(){
    //   var that = this;
    //   if(this.data.currentTab == 0){
    //     const _ = db.command
    //     db.collection('user').where({
    //       phoneNumber: _.eq(that.data.userInfo.phoneNumber),
    //     })
    //     .get({
    //       success: function(res) {
    //         // res.data 是包含以上定义的两条记录的数组
    //         console.log(res.data)
    //       }
    //     })
    //   }
    // },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    },
    
    
})