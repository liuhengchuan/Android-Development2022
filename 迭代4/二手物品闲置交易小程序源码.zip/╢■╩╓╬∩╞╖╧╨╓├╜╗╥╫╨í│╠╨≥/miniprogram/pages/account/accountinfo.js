// pages/account/accountinfo.js
var app = getApp();
var util = require('../../utils/util.js');
const db = wx.cloud.database({env: "cloud1-0g6p9rrd6e6c3359"});
Page({

    /**
     * 页面的初始数据
     */
    data: {
      userdata: "",
    },

    /**
     * 获取我的数据
     */
    getAccountData () {
      try {
        var value = wx.getStorageSync('loginif')
        if (value) {
          this.setData({
            "userdata": wx.getStorageSync('userInfo')
          })
        }else{
          var that = this;
          db.collection("user").doc("6d85a2b9628c9751067bd6803c0b0cba").get({
            success: function(res) {
              console.log(res.data)
              that.setData({
                "userdata":res.data,
              })
            }
          })
        }
      } catch (e) {
        // Do something when catch error
      }
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        this.getAccountData();
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
      
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    },
})