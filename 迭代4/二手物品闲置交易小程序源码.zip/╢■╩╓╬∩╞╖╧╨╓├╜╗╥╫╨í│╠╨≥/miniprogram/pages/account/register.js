// pages/account/register.js
//获取应用实例
var app = getApp();
var util = require('../../utils/util.js');
import WxValidate from '../../utils/validate';

const db = wx.cloud.database();
Page({

    /**
     * 页面的初始数据
     */
    data: {
        userInfo: {
          phonenumber: "",
          nickname: "",
          password: "",
        },
        // paracont: "获取验证码",//验证码文字
        // vcdisabled: true,//验证码按钮状态
        // verifycode: "",//返回的验证码
        passwordSame: false,
        usertype: [  //用户类型
            {value: 1, name: '个人用户', checked: 'true'},
            {value: 2, name: '回收商家'}
        ],
        utitem: [ //用户类型数组
            {value: 2, name: '上门回收者'},
            {value: 3, name: '货场'},
            {value: 4, name: '二手商家'},
        ]
    },
    
    /**
     * 输入手机号
     */
    bindInputPhone: function(e){
      this.setData({
         "userInfo.phonenumber" :e.detail.value,
      })
    },

    /**
     * 输入昵称
     */
    bindInputName: function(e){
      this.setData({
         "userInfo.nickname" :e.detail.value,
      })
      // db.collection("user").where({
      //   phonenumber: this.data.userInfo.phoneNumber,
      //   nickname: this.data.userInfo.nickName
      // }).get({
      //   success: function(res){
      //       console.log(res.data)
      //       wx.showToast({
      //         title: '注册',
      //         icon: "none"
      //       })
      //   }
      // })
    },
    
    /**
     * 输入密码
     */
    bindInputPassword: function(e){
      this.setData({
         "userInfo.password" :e.detail.value,
      })
    },

    /**
     * 验证密码
     */
    bindInputPasswordAgain: function(e){
      var that = this;
      if(e.detail.value === that.data.userInfo.password ){
        this.setData({
          passwordSame: true,
        })
      }
    },

    register(){
      var that = this;
      if(this.data.userInfo.phonenumber.length!=11 ){
        wx.showToast({
          title: '手机号长度错误',
        })
      }else if(!(/(^[0-9]*$)/.test(this.data.userInfo.phonenumber))){
        wx.showToast({
          title: '手机号只能数字',
        })
      }else if(this.data.userInfo.password.length < 6|| this.data.userInfo.password.length > 18){
        wx.showToast({
          title: '密码位数不正确',
        })
      }else{
          if(that.data.passwordSame){
          db.collection('user').add({
            // data 字段表示需新增的 JSON 数据
            data: {
              nickname: that.data.userInfo.nickname,
              password: that.data.userInfo.password,
              phonenumber: that.data.userInfo.phonenumber,
            },
            success: function(res) {
              // res 是一个对象，其中有 _id 字段标记刚创建的记录的 id
              console.log(res)
              // wx.setStorageSync('loginif', false)
              wx.showToast({
                title: '注册成功',
                icon: 'none',
                duration: 2000,
              })
              setTimeout(function(){
                wx.navigateTo({
                  url: 'login'
                })  
              },2000)
            }
          })
        }else{
          wx.showToast({
            title: '密码输入不一致',
          })
        }
      }
    },

    /**
     * radio发生change事件
     */
    radioChange: function (e) {
        if (e.target.dataset.current == 0) {
            console.log('用户类型radio发生change事件，携带value值为：', e.detail.value)
        } else if (e.target.dataset.current == 1) {
            console.log('回收商类型radio发生change事件，携带value值为：', e.detail.value)
        }
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    },

})