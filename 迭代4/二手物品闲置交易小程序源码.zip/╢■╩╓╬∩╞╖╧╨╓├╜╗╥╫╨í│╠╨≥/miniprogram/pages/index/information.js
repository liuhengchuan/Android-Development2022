// pages/index/information.js
var app = getApp();
var util = require('../../utils/util.js');
const db = wx.cloud.database({env: "cloud1-0g6p9rrd6e6c3359"});
Page({

    /**
     * 页面的初始数据
     */
    data: {
        isth: 1,//是否统货
        productList: [
          {value: 1, name: '手机数码'},
          {value: 2, name: '家用电器'},
          {value: 3, name: '运动户外'},
          {value: 4, name: '生活百货'},
          {value: 5, name: '儿童玩具'},
          {value: 6, name: '游戏装备'},
          {value: 7, name: '宠物用品'},
          {value: 8, name: '园艺/农用'},
        ],
        sellerInfo: {
          name: "",
          phonenumber: "",
          address: "",
          street: "街道 门牌号(必填)",
        },
        productInfo: {
          productName: "",
          img: "",
          content: "",
          primaryprice: "",
          nowprice: "",
        },
        streetJudge: false,
        urlArr: [],    //定义一个空数组
        filePath: [],    //初始化空数组
        // lastFilePath: [],
        defaultStreet: ""
    },

    inputProductName: function(e){
      this.setData({
        'productInfo.productName': e.detail.value,
      })
    },

    /**
     * 用户点击checkbox
     */
    checkboxChange: function (e) {
      console.log('checkbox发生change事件，携带value值为：', e.detail.value)

      for (var pindex in this.data.productList) {
          this.data.productList[pindex].checked = false;
          this.setData({
              productList: this.data.productList
          })
      }

      for (var index in e.detail.value) {
          this.data.productList[e.detail.value[index]].checked = true;
          this.setData({
              productList: this.data.productList
          })
      }

  },

    /**
     * 输入名字等信息
     */
    inputName: function(e){
      this.setData({
        'sellerInfo.name': e.detail.value,
      })
    },

    inputPhone: function(e){
      this.setData({
        'sellerInfo.phonenumber': e.detail.value,
      })
    },

    getUserProvince: function(e){
      var city = "";
      for (var index in e.detail.value) {
        city += e.detail.value[index]
    }
      this.setData({
        'sellerInfo.address': city,
        // "streetJudge": true,
        // "defaultStreet": city
      })
    },


    // inputCity:function(e){
    //   var str = ""
    //   if(streetJudge){
    //     // var str = e.detail.value
    //     str = this.data.defaultStreet.toString + e.detail.value.toString
    //     this.setData({
    //       "sellerInfo.address": str
    //     })
    //   }
    //   return {
    //     value: str
    //   }
    // },

    inputStreet: function(e){
      // if(this.data.streetJudge){
      //   return this.data.sellerInfo.street
      // }else{
      this.setData({
        'sellerInfo.street': e.detail.value,
      })
    // }
    },

    inputPrimaryPrice: function(e){
      this.setData({
        'productInfo.primaryprice': e.detail.value,
      })
    },

    inputNowPrice: function(e){
      this.setData({
        'productInfo.nowprice': e.detail.value,
      })
    },

    inputListInformation: function(e){
      this.setData({
        'productInfo.content': e.detail.value,
      })
    },
    
    submit(){
      var that = this;
      db.collection('product').add({
        data: {
          name: that.data.sellerInfo.name,
          phonenumber: that.data.sellerInfo.phonenumber,
          street: that.data.sellerInfo.street,
          address: that.data.sellerInfo.address,
          primaryprice: that.data.productInfo.primaryprice,
          nowprice: that.data.productInfo.nowprice,
          content: that.data.productInfo.content,
          imgSrc: that.data.urlArr,
          category: that.data.productList,
          productName: that.data.productInfo.productName

          // img:
        },
        success: function(res) {
          console.log(res),
          wx.showToast({
            title: '提交成功',
            icon: 'none',
            duration: 2000,
          })
          setTimeout(function(){
            wx.switchTab({
              url: '/pages/index/index'
            })
          },2000)
        }
      })
    },

    getCurrentCity(){
      var that = this;
      wx.chooseLocation({
        success(res){
          that.setData({
            'sellerInfo.street': res.address,
            'streetJudge': true
          })
        }
      })
      // this.inputStreet();
    },

    /**
     * 选择上传图片
     */
    chooseFile:function(){
      console.log('choosefile')
      
      var that = this;
      // 从手机选择图片或视频
      // wx.chooseMedia({
      //   count: 1,
      //   mediaType: ['image','video'],
      //   sourceType: ['album', 'camera'],
      //   maxDuration: 30,
      //   camera: 'back',
      //   success(res) {
      //     console.log(res.tempFiles.tempFilePath)
      //     console.log(res.tempFiles.size)

      //     const filePath = res.tempFiles.tempFilePath
      //     // const cloudPath = filePath.match(/\.[^.]+?$/);
      //     const cloudPath = filePath + Date.parse(new Date());
      //     // 上传图片或视频
      //     wx.cloud.uploadFile({
      //       cloudPath: cloudPath, // 上传至云端的路径
      //       filePath: filePath, // 小程序临时文件路径
      //       success: res => {
      //         // 返回文件 ID
      //         console.log(res.fileID)
      //       },
      //       fail: console.error
      //     })
      //   }
      // })
      // var that = this;
      wx.chooseImage({
        count: 9,
        sizeType: ['original', 'compressed'],
        sourceType: ['album', 'camera'],
        success:res=>{
          console.log()
          that.setData({
            filePath: res.tempFilePaths
          })
          // filePath = res.tempFilePaths
          that.data.filePath.forEach((item,idx)=>{
            var fileName = Date.now() + "_" + idx
            wx.cloud.uploadFile({
              cloudPath:fileName + ".jpg",
              filePath:item,
              // success: res => {
              //   // 返回文件 ID
              //   console.log(res.fileID)
              // },
            })
            .then(res=>{
              that.data.urlArr.push(res.fileID)
              if(that.data.urlArr.length == that.data.filePath.length){  //相等时说明数据全都上传成功
                that.setData({
                    "urlArr":that.data.urlArr
                })
              }
            })
          })
        }
      })
    },
    
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        // this.getInformationData();
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    },
    
})